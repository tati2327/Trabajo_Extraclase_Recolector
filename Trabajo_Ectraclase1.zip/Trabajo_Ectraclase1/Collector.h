class Node;
#ifndef TRABAJO_ECTRACLASE1_COLLECTOR_H
#define TRABAJO_ECTRACLASE1_COLLECTOR_H
#include <cstdlib>

class Collector {

    private:
        Collector();
        static Collector *instanceCollector;

    public:
    //Atributos
        Node *collectorFirst = nullptr;

    //Metodos
        void* newNode(size_t _size);
        void collectNode(void *_node);
        static Collector* getInstance();
};

#endif //TRABAJO_ECTRACLASE1_COLLECTOR_H