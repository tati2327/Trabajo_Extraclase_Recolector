#include <iostream>
#include <stdlib.h>
#include "List.h"

using namespace std;

int main() {

    List list;
    list.insertNode(5);
    list.insertNode(8);
    list.insertNode(3);

    cout<<"jjjjjjjjj "<<list.first<<endl;
    list.deleteNode(5);
    cout<<"qqqqqqqqqqqqq "<<list.first<<endl;

    Collector* c = Collector::getInstance();
    cout<<c->collectorFirst->data;

    return 0;
}