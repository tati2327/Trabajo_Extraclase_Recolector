#ifndef TRABAJO_ECTRACLASE1_LIST_H
#define TRABAJO_ECTRACLASE1_LIST_H

#include "Node.h"
#include "Collector.h"

class List {

    public:
        Node *first = nullptr;

    //Metodos
        List();
        void insertNode(int _data);
        void deleteNode(int n);
        int getFirst();
        void setFirst(int data);
};

#endif //TRABAJO_ECTRACLASE1_LIST_H
