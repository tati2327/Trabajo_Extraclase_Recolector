#include "List.h"
#include "Node.h"
#include <iostream>
#include <stdlib.h>

using  namespace std;

List::List(){
    first = new Node(0, nullptr); //1
}

void List::insertNode(int _data){
    Node*_node = (Node*) _node->operator new(2);

    cout<<"La lista tiene un nodo nuevo"<<endl;
    if(first->data == 0){
        first =_node;
        first->data= _data;
        first->next= nullptr;
        cout<<"La lista inserto su primer nodo"<<endl;
        cout<<first->data<<endl;
    }else{
        _node -> next = first;
        _node -> data = _data;
        first = _node;
        cout<<"La lista inserto un nodo nuevo"<<endl;
        cout<<first->data<<endl;
    }
}

void List::deleteNode(int n) {
    cout<<"firssstt"<<first->data<<endl;
    if (first->data != 0) {
        Node *auxDelete;
        Node *prev = nullptr;
        auxDelete = first;
        cout<<"Se va a borrar un nodo"<<endl;


        cout<<"AUXDELETE: "<<auxDelete->data<<endl;

        while ((auxDelete->data != 0) && (auxDelete->data != n)) {
            cout<<"Entroo al while"<<endl;

            cout<<"AUXDELETE: "<<auxDelete->data<<endl;
            prev = auxDelete;
            auxDelete = auxDelete->next;

            cout<<"AUXDELETE: "<<auxDelete->data<<endl;
        }

        cout<<"AUXDELETE: "<<auxDelete->data<<endl;
        //cout<<"prev: "<<prev->data<<endl;

        //No se encontró el elemento
        if (auxDelete->data == 0) {
            cout << "El elemento no existe"<<endl;
        } else if (prev == nullptr) { //El elemento es el primero de la lista
            first = first->next;
            void*temp = (void*)auxDelete;
            cout<<"kkkkkk"<<temp<<endl;
            first->operator delete(temp);
            cout<<"Nodo eliminado"<<endl;
            return;
        } else { //El elemento está en el medio
            prev->next = auxDelete->next;
            first->operator delete((void*)auxDelete);
            cout<<"Nodo eliminado"<<endl;
        }
    }
}

int List::getFirst() {
    int temp =first->data;
    cout<<"El puntero al inicio de la lista es "<<temp<<endl;
    return temp;
}

void List::setFirst(int newData) {
    first -> data = newData;

    cout<<"El nuevo valor de first es "<<first->data<<endl;
}