#include "Collector.h"
#include "Node.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

Collector* Collector:: instanceCollector = nullptr;

void* Collector::newNode(size_t _size){

    if(collectorFirst == nullptr){
        cout<<"COMPAROOO Y DIO NULL"<<endl;
        int *dir = (int *) malloc(_size);
        cout<<"Se creó un nuevo espacio de memoria"<<endl;
        return dir;
    } else{
        cout<<"COMPAROOO Y DIO QUE COLLECTOR TENIA ELEMENTOS"<<endl;
        Node *dir = collectorFirst;
        dir->next= nullptr;
        collectorFirst = collectorFirst->next;

        cout<<"Se retorno un espacio de memoria"<<endl;
        return dir;
    }
}

void Collector:: collectNode(void *_node){
    cout<<"SE RECOLECTOOOO"<<endl;
    if(collectorFirst == nullptr){
        collectorFirst = (Node*)_node;
        collectorFirst->next = nullptr;
        cout<<"Se recicló un nodo"<<endl;
    }else{
        Node* _node = collectorFirst;
        _node -> next= collectorFirst;
        collectorFirst = _node;
        cout<<"Se recicló un nodo"<<endl;
    }
}

Collector* Collector:: getInstance() {

    if(instanceCollector == nullptr){
        instanceCollector =  new Collector();
        cout<<"Se creó un collector"<<endl;
    }
    return instanceCollector;
}

Collector::Collector() {

}