#ifndef TRABAJO_ECTRACLASE1_NODE_H
#define TRABAJO_ECTRACLASE1_NODE_H
#include "Collector.h"

class Node {

    public:
        //Atributos
        friend class Collector;
        int data;
        Node *next;
        //static Collector *collector;

        //Metodos
        Node(int data, Node* _next);
        int getData();
        void setData(int _data);
        void* operator new(size_t);
        void operator delete(void *memory);
};

#endif //TRABAJO_ECTRACLASE1_NODE_H